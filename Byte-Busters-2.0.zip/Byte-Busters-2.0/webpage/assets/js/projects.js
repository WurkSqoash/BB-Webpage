// I spent 2 days to make this garbage work properly. I hate it so much. -WorkSquash 2024.
// I did this frickin' work for nothing.. fuck it i'm gonna go back to flixel... -WorkSquash

function clearInputField() {
    document.getElementById('inputField').value = '';
}

window.addEventListener('pageshow', clearInputField);
document.getElementById('inputField').addEventListener('input', checkInput);

function checkInput() {
    var inputField = document.getElementById('inputField').value.toLowerCase();
    var validCodes = {
        '0001': '../assets/pdf/neumann-120.pdf',
        '0002': '../assets/pdf/techEd.pdf',
        '0003': '../assets/pdf/template.pdf',
        '...': 'https://github.com/WurkSqoash/Byte-Busters/',
        "fuck it i'm gonna go back to flixel..." : 'https://github.com/WorkSquash/Psych-Deluxe/'
    };

    if (Object.keys(validCodes).includes(inputField)) {
        window.open(validCodes[inputField], '_blank');
        console.log('Az oldal sikeresen megnyitva');
        clearInputField();
    }
}